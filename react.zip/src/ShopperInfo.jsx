import React, { Component } from "react";

export default class ShopperInfo extends Component {
  render() {
    return <div>商家資訊</div>;
  }
}
