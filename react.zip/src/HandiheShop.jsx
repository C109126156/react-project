import React, { Component } from "react";

export default class HandiheShop extends Component {
  render() {
    return (
      <div>
        <div className="container-fluid">
          <h4 className="text-center" style={{ marginTop: "10px" }}>
            汗滴禾Shop
          </h4>
        </div>
      </div>
    );
  }
}
