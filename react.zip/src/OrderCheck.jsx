import React, { Component } from "react";

export default class OrderCheck extends Component {
  render() {
    return <div>訂單查詢</div>;
  }
}
