import React, { Component } from "react";

export default class Introduction extends Component {
  render() {
    return <div>燕巢介紹</div>;
  }
}
