import React, { Component } from "react";

export default class Notification extends Component {
  render() {
    return <div>通知</div>;
  }
}
